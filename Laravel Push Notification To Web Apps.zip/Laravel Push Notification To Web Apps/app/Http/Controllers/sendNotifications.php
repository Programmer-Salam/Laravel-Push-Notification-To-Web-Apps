<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Ladumor\OneSignal\OneSignal;
use RealRashid\SweetAlert\Facades\Alert;
use App\Models\User;
use App\Models\driver;


class sendNotifications extends Controller
{
    public function sendNotifications(Request $request)

    {
   $id= $request->driver_id;
   $ids= $request->id;

  
        // $fieldsh['include_player_ids'] = [$id];

$fieldsh['include_player_ids'] = User::where('id',$ids)->pluck('driver_id');


        $notificationMsgi = 'Successfully Booked!!!';

        OneSignal::sendPush($fieldsh, $notificationMsgi);

    return $this->getAllNotification();

    
    }
    
    public function getAllNotification(){

        OneSignal::getNotifications();
    } 
    
    public function request(){

        return view('request_status');

    } 

    
    public function reg(Request $request)
{


    $id=$request->id;
$token = $request->input('_token');
    $userId = $request->input('userId');

    $notify_database = User::find($id);

$notify_database->_token = $token;
$notify_database->driver_id = $userId;

$notify_database->update();

// return $this->getAllNotification($id);

    return response()->json(['status' => 'success']);


   
}
   


    public function all(){
        $select = User::all();
        return view('sendotp', compact('select'));
     }

 
}
