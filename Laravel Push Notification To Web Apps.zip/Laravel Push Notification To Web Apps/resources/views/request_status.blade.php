@extends('layouts.app')

@section('content')



<body>
<table id="example1" class="table table-bordered table-striped" border="3" style="width:100%; text-align:center; border-collapse:collapse;">

<tr>
    <?php $x = 1; ?>
    <th>S/N</th>
    <th>Driver's Name</th>
    <th>Accept</th>
    <th>Decline</th>
</tr>
<tr>
    <td><?php echo $x++ ?></td>
    <td>Tomiwa</td>
    <td> <button class="btn btn-primary">
    Accept Request
    </button> </td>
    <td><button class="btn btn-danger">Decline Request</button></td>
</tr>

</table>

@endsection












</body>
</html>