@extends('layouts.app')

@section('content')
    <h1 style=" text-align:center;">Book any of the Nearby Drivers </h1>
    <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif
    <table id="example1" class="table table-bordered table-striped" border="3" style="width:100%; text-align:center; border-collapse:collapse;">

<thead>
<tr>



<th>Driver</th>
<th>Book Driver</th>
<th>Player id</th>


</tr>
</thead>
<?php $x=1 ?>




@foreach($select as $row)


<tbody>
    <tr>


    <td> Driver <?php echo $x++ ?></td>
   
<td style="text-align:center;">
<form action="{{url('sendNotification')}}" method="POST" enctype="multipart/form-data">
{{  @csrf_field() }}
<input type="hidden" name="driver_id" value="{{$row->driver_id}}">
<input type="hidden" name="id" value="{{$row->id}}">


<button  class="btn btn-danger btn-xs btn-flat">Book Driver</button>
</form>

                  </td>  
                  <td> <?php echo $row['driver_id']; ?></td>
</tr>

@endforeach
</tbody>

</table>

@endsection