@extends('layouts.app')

@section('content')



{{Auth::user()->name}}

<input type="hidden" id="user_id" value="{{Auth::user()->id}}"/>
<script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>

<script>



OneSignal.push(function() {
    OneSignal.getUserId(function(userId) {
      console.log("OneSignal User ID:", userId);
    //   document.getElementById("user_id").value = user_Id;
    });
});



var OneSignal = window.OneSignal || [];
  OneSignal.push(function() {
    OneSignal.init({
      appId: "XXXXXXXXXXXXXXXXXXXXXXXXXX",
      autoRegister: false,
      notifyButton: {
        enable: true,
      },
    });
    OneSignal.registerForPushNotifications();
  });
     OneSignal.push(function() {
      OneSignal.getUserId(function(userId) {
        // var userIds = 123; 
        var token = "{{ csrf_token() }}";
var url = "{{ url('user/save-push-notification-token') }}";
var user_id= document.getElementById("user_id").value ;

let data = {
    'id': user_id,
   '_token': token,
  'userId': userId,
};
       // Create a new XMLHttpRequest object
var xhr = new XMLHttpRequest();

// Open a POST request to the URL
xhr.open('POST', url,true);

// Set the request headers
xhr.setRequestHeader('Content-Type', 'application/json');
xhr.setRequestHeader('X-CSRF-TOKEN', token);

// Send the data as a JSON string
  xhr.send(JSON.stringify(data));

// Handle the response from the server
xhr.onload = function() {
  if (xhr.status === 200) {
    // Success
    console.log(xhr.responseText);
  } else {
    // Error
    console.error(xhr.statusText);
  }
}

      });
    });

    

</script>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('Dashboard') }}</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

                    {{ __('You are logged in!') }}
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
