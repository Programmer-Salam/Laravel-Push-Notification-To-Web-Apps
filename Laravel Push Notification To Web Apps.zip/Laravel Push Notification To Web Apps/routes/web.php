<?php

use Illuminate\Support\Facades\Route;
Use App\Http\Controllers\sendNotifications;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

Route::get('request', [App\Http\Controllers\sendNotifications::class, 'request'])->name('request');

// Route::put('sendNotification/{id}',[UserController::class,'sendNotifications']);


// Route::put('lot/{id}',[UserController::class,'sendNotificationrToUser']);

Route::post('sendNotification',[sendNotifications::class, 'sendNotifications']);

Route::get('alldriver',[sendNotifications::class, 'all']);


Route::any('/user/save-push-notification-token', [sendNotifications::class, 'reg'])
->name('/user/save-push-notification-token');