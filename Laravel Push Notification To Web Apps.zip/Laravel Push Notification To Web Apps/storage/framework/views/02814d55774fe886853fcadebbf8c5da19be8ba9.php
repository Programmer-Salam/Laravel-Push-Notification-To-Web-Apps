<?php $__env->startSection('content'); ?>

<?php echo e(Auth::user()->name); ?>


<input type="hidden" id="user_id" value="<?php echo e(Auth::user()->id); ?>"/>

        <script src="https://cdn.onesignal.com/sdks/OneSignalSDK.js" async=""></script>
<script>
  window.OneSignal = window.OneSignal || [];
  OneSignal.push(function() {
    OneSignal.init({
      appId: "70713ce0-72a6-418a-bbe0-c6b2b8b972a3",
    });
  });

  OneSignal.push(function() {
    OneSignal.getUserId(function(userId) {
      console.log("OneSignal User ID:", userId);
      document.getElementById("user_id").value = user_Id;
    });
});

var OneSignal = window.OneSignal || [];
  OneSignal.push(function() {
    OneSignal.init({
      appId: "XXXXXXXXXXXXXXXXXXXXXXXXXX",
      autoRegister: false,
      notifyButton: {
        enable: true,
      },
    });
    OneSignal.registerForPushNotifications();
  });
     OneSignal.push(function() {
      OneSignal.getUserId(function(userId) {
        // var userIds = 123; 
        var token = "<?php echo e(csrf_token()); ?>";
var url = "<?php echo e(url('user/save-push-notification-token')); ?>";
var user_id= document.getElementById("user_id").value ;

let data = {
    'id': user_id,
   '_token': token,
  'userId': userId,
};
       // Create a new XMLHttpRequest object
var xhr = new XMLHttpRequest();

// Open a POST request to the URL
xhr.open('POST', url,true);

// Set the request headers
xhr.setRequestHeader('Content-Type', 'application/json');
xhr.setRequestHeader('X-CSRF-TOKEN', token);

// Send the data as a JSON string
  xhr.send(JSON.stringify(data));

// Handle the response from the server
xhr.onload = function() {
  if (xhr.status === 200) {
    // Success
    console.log(xhr.responseText);
  } else {
    // Error
    console.error(xhr.statusText);
  }
}

      });
    });

    



</script>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php echo e(__('You are logged in!')); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\One_singal\resources\views/home.blade.php ENDPATH**/ ?>