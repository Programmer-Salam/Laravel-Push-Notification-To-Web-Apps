

<?php $__env->startSection('content'); ?>
    <h1 style=" text-align:center;">Book any of the Nearby Drivers </h1>
    <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
    <table id="example1" class="table table-bordered table-striped" border="3" style="width:100%; text-align:center; border-collapse:collapse;">

<thead>
<tr>



<th>Driver</th>
<th>Book Driver</th>
<th>Player id</th>


</tr>
</thead>
<?php $x=1 ?>




<?php $__currentLoopData = $select; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


<tbody>
    <tr>


    <td> Driver <?php echo $x++ ?></td>
   
<td style="text-align:center;">
<form action="<?php echo e(url('sendNotification')); ?>" method="POST" enctype="multipart/form-data">
<?php echo e(@csrf_field()); ?>

<input type="hidden" name="driver_id" value="<?php echo e($row->driver_id); ?>">
<input type="hidden" name="id" value="<?php echo e($row->id); ?>">


<button  class="btn btn-danger btn-xs btn-flat">Book Driver</button>
</form>

                  </td>  
                  <td> <?php echo $row['driver_id']; ?></td>
</tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>

</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\signal\resources\views/sendotp.blade.php ENDPATH**/ ?>